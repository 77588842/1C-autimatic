﻿# Vanessa Automation

[![GitHub release](https://img.shields.io/github/release/Pr-Mex/vanessa-automation.svg)](docs/Changelog.md)
[![Build Status](http://vanessa.bit-erp.ru/buildStatus/icon?job=VAFullCheck)](http://vanessa.bit-erp.ru/job/VAFullCheck/)
[![GitHub Releases](https://img.shields.io/github/downloads/Pr-Mex/vanessa-automation/latest/total?style=flat-square)](https://github.com/Pr-Mex/vanessa-automation/releases)
[![GitHub All Releases](https://img.shields.io/github/downloads/Pr-Mex/vanessa-automation/total?style=flat-square)](https://github.com/Pr-Mex/vanessa-automation/releases)
[![telegram](https://img.shields.io/badge/telegram-chat-green.svg)](https://t.me/testspro1c)

## Документация

https://pr-mex.github.io/vanessa-automation/dev

## Лицензии

* основная лицензия продукта - BSD v3
* лицензии стороннего кода - Apache License, GitHub CLA, Freeware, etc
